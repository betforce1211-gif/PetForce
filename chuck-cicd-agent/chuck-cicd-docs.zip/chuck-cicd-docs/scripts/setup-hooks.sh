#!/bin/bash
# scripts/setup-hooks.sh
# Sets up git hooks for Chuck CI/CD Guardian

set -e

HOOKS_DIR=".git/hooks"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🤖 Chuck: Setting up git hooks..."

# Create hooks directory if it doesn't exist
mkdir -p "$HOOKS_DIR"

# =====================================================
# COMMIT-MSG HOOK
# Validates commit messages follow conventional format
# =====================================================
cat > "$HOOKS_DIR/commit-msg" << 'HOOK'
#!/bin/bash
# Chuck's commit message validator

COMMIT_MSG_FILE=$1
COMMIT_MSG=$(cat "$COMMIT_MSG_FILE")

# Skip merge commits
if [[ "$COMMIT_MSG" =~ ^Merge ]]; then
    exit 0
fi

# Conventional commit pattern
# type(scope)?: subject [TICKET-ID]
PATTERN="^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\(.+\))?(!)?: .{1,72}( \[[A-Z]+-[0-9]+\])?$"

# Get first line (subject)
SUBJECT=$(echo "$COMMIT_MSG" | head -n 1)

if [[ ! "$SUBJECT" =~ $PATTERN ]]; then
    echo ""
    echo "❌ Chuck: Invalid commit message format"
    echo ""
    echo "Your message:"
    echo "  $SUBJECT"
    echo ""
    echo "Expected format:"
    echo "  type(scope): description [TICKET-ID]"
    echo ""
    echo "Valid types: feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert"
    echo ""
    echo "Examples:"
    echo "  feat(auth): add OAuth2 login [PROJ-123]"
    echo "  fix(api): resolve null pointer in user service [PROJ-456]"
    echo "  docs: update README with new API endpoints [PROJ-789]"
    echo ""
    exit 1
fi

# Check subject length
if [ ${#SUBJECT} -gt 72 ]; then
    echo ""
    echo "❌ Chuck: Commit subject too long (${#SUBJECT} > 72 characters)"
    echo ""
    echo "Please shorten your commit message subject line."
    echo ""
    exit 1
fi

echo "✅ Chuck: Commit message valid"
HOOK

chmod +x "$HOOKS_DIR/commit-msg"
echo "  ✓ commit-msg hook installed"

# =====================================================
# PRE-COMMIT HOOK
# Runs linting and formatting checks
# =====================================================
cat > "$HOOKS_DIR/pre-commit" << 'HOOK'
#!/bin/bash
# Chuck's pre-commit validator

echo "🔍 Chuck: Running pre-commit checks..."

# Get list of staged files
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
    echo "✅ No files to check"
    exit 0
fi

# Check for lint script
if npm run --silent lint -- --help >/dev/null 2>&1; then
    echo "  Running lint..."
    
    # Get staged JS/TS files
    JS_FILES=$(echo "$STAGED_FILES" | grep -E '\.(js|jsx|ts|tsx)$' || true)
    
    if [ -n "$JS_FILES" ]; then
        # Run lint only on staged files
        if ! echo "$JS_FILES" | xargs npm run lint -- --max-warnings=0 2>/dev/null; then
            echo ""
            echo "❌ Chuck: Linting failed"
            echo "Run 'npm run lint:fix' to auto-fix issues"
            exit 1
        fi
    fi
    echo "  ✓ Lint passed"
fi

# Check for format script
if npm run --silent format:check -- --help >/dev/null 2>&1; then
    echo "  Running format check..."
    
    if ! npm run format:check -- $STAGED_FILES 2>/dev/null; then
        echo ""
        echo "❌ Chuck: Formatting issues found"
        echo "Run 'npm run format' to fix"
        exit 1
    fi
    echo "  ✓ Format check passed"
fi

echo "✅ Chuck: Pre-commit checks passed"
HOOK

chmod +x "$HOOKS_DIR/pre-commit"
echo "  ✓ pre-commit hook installed"

# =====================================================
# PRE-PUSH HOOK
# Runs tests before pushing
# =====================================================
cat > "$HOOKS_DIR/pre-push" << 'HOOK'
#!/bin/bash
# Chuck's pre-push validator

echo "🧪 Chuck: Running pre-push checks..."

# Get the remote and branch being pushed to
remote="$1"
url="$2"

# Read pushed refs
while read local_ref local_sha remote_ref remote_sha
do
    # Skip deletes
    if [ "$local_sha" = "0000000000000000000000000000000000000000" ]; then
        continue
    fi
    
    # Check if pushing to protected branch
    BRANCH=$(echo "$remote_ref" | sed 's|refs/heads/||')
    
    if [[ "$BRANCH" == "main" || "$BRANCH" == "develop" ]]; then
        echo "⚠️  Chuck: Attempting to push directly to protected branch: $BRANCH"
        echo ""
        echo "Direct pushes to $BRANCH are not recommended."
        echo "Please create a feature branch and open a PR instead."
        echo ""
        echo "To bypass (not recommended): git push --no-verify"
        exit 1
    fi
done

# Run type check if available
if npm run --silent typecheck -- --help >/dev/null 2>&1; then
    echo "  Running type check..."
    if ! npm run typecheck 2>/dev/null; then
        echo ""
        echo "❌ Chuck: TypeScript errors found"
        exit 1
    fi
    echo "  ✓ Type check passed"
fi

# Run tests
if npm run --silent test -- --help >/dev/null 2>&1; then
    echo "  Running tests..."
    if ! npm test 2>/dev/null; then
        echo ""
        echo "❌ Chuck: Tests failed"
        echo "Fix failing tests before pushing"
        exit 1
    fi
    echo "  ✓ Tests passed"
fi

echo "✅ Chuck: Pre-push checks passed"
HOOK

chmod +x "$HOOKS_DIR/pre-push"
echo "  ✓ pre-push hook installed"

# =====================================================
# PREPARE-COMMIT-MSG HOOK
# Adds ticket ID from branch name to commit message
# =====================================================
cat > "$HOOKS_DIR/prepare-commit-msg" << 'HOOK'
#!/bin/bash
# Chuck's commit message preparer

COMMIT_MSG_FILE=$1
COMMIT_SOURCE=$2
SHA1=$3

# Only run for regular commits (not merge, squash, etc.)
if [ -n "$COMMIT_SOURCE" ]; then
    exit 0
fi

# Get current branch name
BRANCH=$(git rev-parse --abbrev-ref HEAD)

# Extract ticket ID from branch name
# Matches patterns like: feature/PROJ-123-description
TICKET=$(echo "$BRANCH" | grep -oE '[A-Z]+-[0-9]+' | head -n 1)

if [ -n "$TICKET" ]; then
    # Check if ticket is already in the message
    if ! grep -q "\[$TICKET\]" "$COMMIT_MSG_FILE"; then
        # Read existing message
        MSG=$(cat "$COMMIT_MSG_FILE")
        
        # Get first line
        FIRST_LINE=$(echo "$MSG" | head -n 1)
        REST=$(echo "$MSG" | tail -n +2)
        
        # Add ticket to first line if not empty
        if [ -n "$FIRST_LINE" ]; then
            echo "$FIRST_LINE [$TICKET]" > "$COMMIT_MSG_FILE"
            echo "$REST" >> "$COMMIT_MSG_FILE"
        fi
    fi
fi
HOOK

chmod +x "$HOOKS_DIR/prepare-commit-msg"
echo "  ✓ prepare-commit-msg hook installed"

# =====================================================
# Configure commit template
# =====================================================
if [ -f "templates/.gitmessage" ]; then
    git config commit.template templates/.gitmessage
    echo "  ✓ Commit message template configured"
fi

echo ""
echo "🤖 Chuck: Git hooks setup complete!"
echo ""
echo "Installed hooks:"
echo "  • commit-msg      - Validates commit message format"
echo "  • pre-commit      - Runs lint and format checks"
echo "  • pre-push        - Runs tests, blocks direct pushes to protected branches"
echo "  • prepare-commit-msg - Auto-adds ticket ID from branch name"
echo ""
echo "To skip hooks temporarily: git commit --no-verify"
echo ""
