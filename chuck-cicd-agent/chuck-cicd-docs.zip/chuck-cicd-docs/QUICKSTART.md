# Chuck CI/CD Guardian - Quick Start Guide

Get Chuck up and running in your repository in 5 minutes.

## Prerequisites

- GitHub repository
- Node.js project with `package.json`
- npm scripts: `lint`, `test`, `build` (recommended)

---

## Step 1: Add Configuration Files

### Copy these files to your repository:

```
your-repo/
├── .github/
│   ├── workflows/
│   │   ├── chuck-ci.yml        # Main CI pipeline
│   │   └── chuck-release.yml   # Release workflow
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── CODEOWNERS              # Optional
├── .chuck.yml                   # Chuck configuration
├── CLAUDE.md                    # Claude Code agent config
└── CHANGELOG.md                 # If not exists
```

### Quick copy commands:

```bash
# Create directories
mkdir -p .github/workflows

# Copy from this package (adjust path as needed)
cp chuck-cicd-docs/.github/workflows/*.yml .github/workflows/
cp chuck-cicd-docs/.github/PULL_REQUEST_TEMPLATE.md .github/
cp chuck-cicd-docs/.chuck.yml .
cp chuck-cicd-docs/CLAUDE.md .
```

---

## Step 2: Configure Your Project

### Update `.chuck.yml`

Edit the configuration for your project:

```yaml
# .chuck.yml - Minimum required changes

version: 1

branches:
  protected:
    - main
    - develop  # Remove if not using GitFlow

commits:
  require_ticket: true
  ticket_pattern: '[A-Z]+-[0-9]+'  # Adjust for your ticket system

tests:
  coverage:
    line: 80     # Adjust based on current coverage
    branch: 75

quality:
  lint:
    command: 'npm run lint'
  format:
    command: 'npm run format:check'
  typecheck:
    command: 'npm run typecheck'  # Or 'tsc --noEmit'
```

### Ensure npm scripts exist

Your `package.json` should have:

```json
{
  "scripts": {
    "lint": "eslint .",
    "lint:fix": "eslint . --fix",
    "format:check": "prettier --check .",
    "format": "prettier --write .",
    "typecheck": "tsc --noEmit",
    "test": "jest",
    "build": "your-build-command"
  }
}
```

---

## Step 3: Set Up Branch Protection

### Option A: GitHub CLI (Recommended)

```bash
# Install gh if needed: https://cli.github.com/

# Main branch
gh api repos/{owner}/{repo}/branches/main/protection \
  --method PUT \
  --field required_status_checks='{"strict":true,"contexts":["🌿 Branch Validation","🔍 Lint & Format","🧪 Tests","🏗️ Build"]}' \
  --field required_pull_request_reviews='{"required_approving_review_count":1}'

# Develop branch (if using)
gh api repos/{owner}/{repo}/branches/develop/protection \
  --method PUT \
  --field required_status_checks='{"strict":true,"contexts":["🌿 Branch Validation","🔍 Lint & Format","🧪 Tests","🏗️ Build"]}' \
  --field required_pull_request_reviews='{"required_approving_review_count":1}'
```

### Option B: GitHub UI

1. Go to **Settings** → **Branches**
2. Click **Add rule**
3. Branch pattern: `main`
4. Enable:
   - [x] Require status checks
   - [x] Require PR before merging
   - [x] Required approvals: 1+
5. Save

---

## Step 4: Initialize CHANGELOG

If you don't have a CHANGELOG.md:

```bash
cat > CHANGELOG.md << 'EOF'
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added
- Chuck CI/CD Guardian integration

EOF
```

---

## Step 5: Commit and Push

```bash
# Create a properly named branch
git checkout -b chore/PROJ-001-add-chuck-cicd

# Add files
git add .github/ .chuck.yml CLAUDE.md CHANGELOG.md

# Commit with conventional format
git commit -m "chore(ci): add Chuck CI/CD Guardian [PROJ-001]"

# Push
git push -u origin chore/PROJ-001-add-chuck-cicd
```

---

## Step 6: Create Initial PR

```bash
gh pr create \
  --title "chore(ci): add Chuck CI/CD Guardian [PROJ-001]" \
  --body "## Summary
Adds Chuck CI/CD Guardian for automated quality enforcement.

## Type of Change
- [x] 🔧 Configuration/build changes

## Changes Made
- Added GitHub Actions workflows
- Added PR template
- Added Chuck configuration
- Added CHANGELOG

## Testing
- [x] Workflows will run on this PR

## Checklist
- [x] Configuration follows project standards
- [x] CHANGELOG updated"
```

---

## Step 7: Verify Setup

After the PR is created, check:

1. ✅ GitHub Actions workflow runs
2. ✅ Status checks appear on PR
3. ✅ Chuck's Verdict comment is posted
4. ✅ PR template is populated

---

## Using Chuck with Claude Code

Once set up, open Claude Code in your repository and Chuck will:

1. **Validate branches** when you create them
2. **Check commits** as you make them  
3. **Run full validation** before PRs
4. **Guide you** through any failures

### Example interaction:

```
You: I want to start working on a new feature for user authentication

Chuck: I'll help you set up a proper feature branch. What's your ticket ID?

You: PROJ-456

Chuck: Created branch: feature/PROJ-456-user-authentication
✅ Branch name follows convention
Remember to use conventional commits like:
  feat(auth): add login endpoint
```

---

## Customization

### Adjust Coverage Thresholds

If your current coverage is lower:

```yaml
# .chuck.yml
tests:
  coverage:
    line: 60   # Start lower
    branch: 50
```

Gradually increase as you add tests.

### Disable Specific Checks

```yaml
# .chuck.yml
quality:
  typecheck:
    enabled: false  # If not using TypeScript
```

### Custom Ticket Pattern

```yaml
# .chuck.yml
commits:
  ticket_pattern: 'GH-[0-9]+'  # For GitHub issues
  # Or: '#[0-9]+'              # Simple issue numbers
```

---

## Troubleshooting

### "Status check not found"

Workflows must run once before checks are available for branch protection.
Push any commit to trigger the first run.

### "Branch name invalid"

```bash
# Rename your branch
git branch -m feature/PROJ-XXX-description
git push -u origin feature/PROJ-XXX-description
```

### "Coverage threshold not met"

```bash
# Check current coverage
npm test -- --coverage

# See uncovered files
cat coverage/lcov-report/index.html
```

### "Commit message invalid"

```bash
# Amend last commit
git commit --amend -m "feat(scope): proper message [PROJ-123]"

# Rebase to fix older commits
git rebase -i HEAD~N
# Change 'pick' to 'reword' for commits to fix
```

---

## Next Steps

1. 📖 Read full [CHUCK.md](./CHUCK.md) documentation
2. 🔒 Set up [branch protection](./docs/BRANCH_PROTECTION_SETUP.md) fully
3. 👥 Add [CODEOWNERS](./.github/CODEOWNERS) for auto-review
4. 🚀 Configure [release workflow](./.github/workflows/chuck-release.yml)

---

*Welcome to cleaner code and better git hygiene with Chuck! 🤖*
