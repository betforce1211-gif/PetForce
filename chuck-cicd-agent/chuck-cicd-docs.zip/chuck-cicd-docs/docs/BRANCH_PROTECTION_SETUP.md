# GitHub Branch Protection Setup for Chuck

This guide configures GitHub branch protection rules to work with Chuck's CI/CD pipeline.

## Quick Setup via GitHub CLI

Run these commands to set up branch protection (requires `gh` CLI):

```bash
# Login to GitHub CLI if not already
gh auth login

# Set up main branch protection
gh api repos/{owner}/{repo}/branches/main/protection \
  --method PUT \
  --field required_status_checks='{"strict":true,"contexts":["chuck/branch-validation","chuck/lint-and-format","chuck/tests","chuck/build","✅ Chuck'"'"'s Verdict"]}' \
  --field enforce_admins=true \
  --field required_pull_request_reviews='{"required_approving_review_count":2,"dismiss_stale_reviews":true,"require_code_owner_reviews":true}' \
  --field restrictions=null \
  --field allow_force_pushes=false \
  --field allow_deletions=false

# Set up develop branch protection
gh api repos/{owner}/{repo}/branches/develop/protection \
  --method PUT \
  --field required_status_checks='{"strict":true,"contexts":["chuck/branch-validation","chuck/lint-and-format","chuck/tests","chuck/build"]}' \
  --field enforce_admins=false \
  --field required_pull_request_reviews='{"required_approving_review_count":1,"dismiss_stale_reviews":true}' \
  --field restrictions=null \
  --field allow_force_pushes=false \
  --field allow_deletions=false
```

---

## Manual Setup via GitHub UI

### Main Branch Protection

1. Go to **Settings** → **Branches** → **Add branch protection rule**

2. **Branch name pattern:** `main`

3. **Protect matching branches:**

   #### Required Status Checks
   - [x] Require status checks to pass before merging
   - [x] Require branches to be up to date before merging
   
   **Select checks:**
   - `chuck/branch-validation`
   - `chuck/lint-and-format`
   - `chuck/tests`
   - `chuck/build`
   - `✅ Chuck's Verdict`

   #### Required Reviews
   - [x] Require a pull request before merging
   - [x] Required approvals: **2**
   - [x] Dismiss stale pull request approvals when new commits are pushed
   - [x] Require review from Code Owners
   - [x] Require approval of the most recent reviewable push

   #### Additional Settings
   - [x] Require conversation resolution before merging
   - [x] Require signed commits (optional, recommended)
   - [x] Require linear history
   - [ ] Allow force pushes → **DISABLED**
   - [ ] Allow deletions → **DISABLED**

   #### Restrictions
   - [x] Restrict who can push to matching branches
   - Add: `release-bot` (if using automated releases)

4. Click **Create**

---

### Develop Branch Protection

1. **Branch name pattern:** `develop`

2. **Settings:**

   #### Required Status Checks
   - [x] Require status checks to pass before merging
   - [x] Require branches to be up to date before merging
   
   **Select checks:**
   - `chuck/branch-validation`
   - `chuck/lint-and-format`
   - `chuck/tests`
   - `chuck/build`

   #### Required Reviews
   - [x] Require a pull request before merging
   - [x] Required approvals: **1**
   - [x] Dismiss stale pull request approvals when new commits are pushed

   #### Additional Settings
   - [x] Require conversation resolution before merging
   - [ ] Allow force pushes → **DISABLED**
   - [ ] Allow deletions → **DISABLED**

3. Click **Create**

---

### Release Branch Protection

1. **Branch name pattern:** `release/*`

2. **Settings:**

   #### Required Status Checks
   - [x] Require status checks to pass before merging
   
   **Select checks:**
   - All checks from Chuck Release workflow

   #### Required Reviews
   - [x] Require a pull request before merging
   - [x] Required approvals: **2**
   - [x] Require review from Code Owners

   #### Restrictions
   - [x] Restrict who can push to matching branches
   - Add: Release managers only

3. Click **Create**

---

## Rulesets (GitHub Enterprise / New Features)

For repositories using GitHub's newer Rulesets feature:

### Create Repository Ruleset

```json
{
  "name": "Chuck Protection Rules",
  "target": "branch",
  "enforcement": "active",
  "conditions": {
    "ref_name": {
      "include": ["refs/heads/main", "refs/heads/develop"],
      "exclude": []
    }
  },
  "rules": [
    {
      "type": "pull_request",
      "parameters": {
        "required_approving_review_count": 1,
        "dismiss_stale_reviews_on_push": true,
        "require_code_owner_review": true,
        "require_last_push_approval": true
      }
    },
    {
      "type": "required_status_checks",
      "parameters": {
        "strict_required_status_checks_policy": true,
        "required_status_checks": [
          { "context": "chuck/branch-validation" },
          { "context": "chuck/lint-and-format" },
          { "context": "chuck/tests" },
          { "context": "chuck/build" }
        ]
      }
    },
    {
      "type": "non_fast_forward"
    }
  ]
}
```

---

## CODEOWNERS File

Create `.github/CODEOWNERS` for automatic review requests:

```
# Default owners for everything
*       @your-org/core-team

# Frontend code
/src/ui/          @your-org/frontend-team
/src/components/  @your-org/frontend-team

# Backend/API code
/src/api/         @your-org/backend-team
/src/services/    @your-org/backend-team

# Infrastructure
/.github/         @your-org/devops-team
/infrastructure/  @your-org/devops-team
/docker/          @your-org/devops-team

# Documentation
/docs/            @your-org/docs-team
*.md              @your-org/docs-team

# Security-sensitive files
/src/auth/        @your-org/security-team
/src/crypto/      @your-org/security-team
```

---

## Required Repository Settings

### General Settings

1. **Settings** → **General**
   - [x] Allow squash merging → **Default commit message: PR title and description**
   - [ ] Allow merge commits → **DISABLED** (optional, for cleaner history)
   - [ ] Allow rebase merging → **DISABLED** (optional)
   - [x] Automatically delete head branches

### Actions Permissions

1. **Settings** → **Actions** → **General**
   - [x] Allow all actions and reusable workflows
   - [x] Allow GitHub Actions to create and approve pull requests

### Secrets

1. **Settings** → **Secrets and variables** → **Actions**
   
   Required secrets:
   - `NPM_TOKEN` - For publishing to npm (if applicable)
   - `SLACK_WEBHOOK_URL` - For Slack notifications (optional)

---

## Verification Checklist

After setup, verify:

- [ ] PRs to `main` require 2 approvals
- [ ] PRs to `develop` require 1 approval
- [ ] All Chuck status checks appear in PR
- [ ] Direct pushes to protected branches are blocked
- [ ] Force pushes are disabled
- [ ] Stale reviews are dismissed on new commits
- [ ] CODEOWNERS auto-request reviews
- [ ] Squash merge is the default/only option

---

## Troubleshooting

### Status checks not appearing

1. Ensure workflows have run at least once
2. Check workflow file is in `.github/workflows/`
3. Verify job names match protection rules

### "Required status check is expected"

1. Push any change to trigger workflows
2. Wait for initial run to complete
3. Status checks will then be available for selection

### Branch protection not enforcing

1. Verify rule pattern matches branch exactly
2. Check "Enforce for administrators" if needed
3. Ensure no bypass permissions granted

---

*Chuck recommends strict branch protection for a healthy codebase! 🤖*
