## Summary
<!-- Provide a brief description of the changes in this PR -->

## Type of Change
<!-- Check all that apply -->

- [ ] 🐛 Bug fix (non-breaking change fixing an issue)
- [ ] ✨ New feature (non-breaking change adding functionality)
- [ ] 💥 Breaking change (fix or feature causing existing functionality to change)
- [ ] 📚 Documentation update
- [ ] ♻️ Refactoring (no functional changes)
- [ ] 🧪 Test addition/update
- [ ] 🔧 Configuration/build changes
- [ ] 🎨 Style/formatting changes

## Related Issues
<!-- Link related issues below. Use keywords to auto-close: Closes #123, Fixes #456 -->

Closes #

## Changes Made
<!-- Provide a detailed list of changes -->

- 
- 
- 

## Testing
<!-- Describe how these changes were tested -->

### Test Coverage
- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] E2E tests added/updated (if applicable)
- [ ] Manual testing performed

### Testing Steps
<!-- Provide steps to test the changes -->

1. 
2. 
3. 

## Screenshots (if applicable)
<!-- Add screenshots for UI changes -->

| Before | After |
|--------|-------|
|        |       |

## Breaking Changes (if applicable)
<!-- Describe breaking changes and migration steps -->

### What's Breaking
<!-- Describe what will break -->

### Migration Guide
<!-- How should users migrate? -->

```diff
- old way
+ new way
```

## Checklist
<!-- Complete all items before requesting review -->

### Code Quality
- [ ] My code follows the project's style guidelines
- [ ] I have performed a self-review of my code
- [ ] I have commented hard-to-understand areas
- [ ] My changes generate no new warnings or errors

### Testing
- [ ] I have added tests that prove my fix/feature works
- [ ] New and existing unit tests pass locally
- [ ] Test coverage meets or exceeds thresholds (80% line, 75% branch)

### Documentation
- [ ] I have updated the README (if needed)
- [ ] I have updated API documentation (if needed)
- [ ] I have added a CHANGELOG entry
- [ ] I have created/updated ADR (if architectural change)

### Git Hygiene
- [ ] My commits follow conventional commit format
- [ ] My branch is up-to-date with the base branch
- [ ] I have squashed/cleaned up WIP commits

## Additional Notes
<!-- Any additional information for reviewers -->

---

> 🤖 **Chuck Reminder**: All checks must pass before merge. Run `chuck check all` locally to validate.
